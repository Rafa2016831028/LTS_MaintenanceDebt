/*******************************************************************************
 * Copyright (c) 2012-2016 Codenvy, S.A.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   Codenvy, S.A. - initial API and implementation
 *******************************************************************************/
package org.eclipse.che.plugin.docker.machine;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.MoreObjects;
import com.google.common.base.Strings;
import com.google.common.collect.ObjectArrays;
import com.google.common.util.concurrent.ThreadFactoryBuilder;

import org.eclipse.che.api.core.NotFoundException;
import org.eclipse.che.api.core.ServerException;
import org.eclipse.che.api.core.model.machine.MachineStatus;
import org.eclipse.che.api.core.model.machine.ServerConf;
import org.eclipse.che.api.core.util.FileCleaner;
import org.eclipse.che.api.core.util.LineConsumer;
import org.eclipse.che.api.core.util.SystemInfo;
import org.eclipse.che.api.environment.server.compose.ComposeMachineInstanceProvider;
import org.eclipse.che.api.environment.server.compose.model.ComposeServiceImpl;
import org.eclipse.che.api.machine.server.exception.MachineException;
import org.eclipse.che.api.machine.server.exception.SourceNotFoundException;
import org.eclipse.che.api.machine.server.model.impl.MachineLimitsImpl;
import org.eclipse.che.api.machine.server.model.impl.MachineConfigImpl;
import org.eclipse.che.api.machine.server.model.impl.MachineImpl;
import org.eclipse.che.api.machine.server.model.impl.MachineSourceImpl;
import org.eclipse.che.api.machine.server.spi.Instance;
import org.eclipse.che.commons.annotation.Nullable;
import org.eclipse.che.commons.env.EnvironmentContext;
import org.eclipse.che.commons.lang.Size;
import org.eclipse.che.plugin.docker.client.DockerConnector;
import org.eclipse.che.plugin.docker.client.DockerConnectorConfiguration;
import org.eclipse.che.plugin.docker.client.ProgressLineFormatterImpl;
import org.eclipse.che.plugin.docker.client.ProgressMonitor;
import org.eclipse.che.plugin.docker.client.UserSpecificDockerRegistryCredentialsProvider;
import org.eclipse.che.plugin.docker.client.exception.ContainerNotFoundException;
import org.eclipse.che.plugin.docker.client.exception.ImageNotFoundException;
import org.eclipse.che.plugin.docker.client.exception.NetworkNotFoundException;
import org.eclipse.che.plugin.docker.client.json.ContainerConfig;
import org.eclipse.che.plugin.docker.client.json.HostConfig;
import org.eclipse.che.plugin.docker.client.json.PortBinding;
import org.eclipse.che.plugin.docker.client.json.container.NetworkingConfig;
import org.eclipse.che.plugin.docker.client.json.network.EndpointConfig;
import org.eclipse.che.plugin.docker.client.json.network.NewNetwork;
import org.eclipse.che.plugin.docker.client.params.BuildImageParams;
import org.eclipse.che.plugin.docker.client.params.CreateContainerParams;
import org.eclipse.che.plugin.docker.client.params.GetContainerLogsParams;
import org.eclipse.che.plugin.docker.client.params.PullParams;
import org.eclipse.che.plugin.docker.client.params.RemoveContainerParams;
import org.eclipse.che.plugin.docker.client.params.RemoveImageParams;
import org.eclipse.che.plugin.docker.client.params.RemoveNetworkParams;
import org.eclipse.che.plugin.docker.client.params.StartContainerParams;
import org.eclipse.che.plugin.docker.client.params.TagParams;
import org.eclipse.che.plugin.docker.client.params.network.CreateNetworkParams;
import org.eclipse.che.plugin.docker.machine.node.DockerNode;
import org.eclipse.che.plugin.docker.machine.node.WorkspaceFolderPathProvider;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.SocketTimeoutException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.lang.String.format;
import static java.util.Collections.singletonMap;
import static org.eclipse.che.plugin.docker.machine.DockerInstance.LATEST_TAG;
import static org.slf4j.LoggerFactory.getLogger;

/**
 * Creates/destroys docker networks and creates docker compose based {@link Instance}.
 *
 * @author Alexander Garagatyi
 */
public class ComposeMachineProviderImpl implements ComposeMachineInstanceProvider {
    private static final Logger LOG = getLogger(ComposeMachineProviderImpl.class);

    /**
     * Prefix of image repository, used to identify that the image is a machine saved to snapshot.
     */
    public static final String MACHINE_SNAPSHOT_PREFIX = "machine_snapshot_";

    public static final Pattern SNAPSHOT_LOCATION_PATTERN = Pattern.compile("(.+/)?" + MACHINE_SNAPSHOT_PREFIX + ".+");

    private final DockerConnector                               docker;
    private final UserSpecificDockerRegistryCredentialsProvider dockerCredentials;
    private final ExecutorService                               executor;
    private final DockerInstanceStopDetector                    dockerInstanceStopDetector;
    private final DockerContainerNameGenerator                  containerNameGenerator;
    private final WorkspaceFolderPathProvider                   workspaceFolderPathProvider;
    private final boolean                                       doForcePullOnBuild;
    private final boolean                                       privilegeMode;
    private final DockerMachineFactory                          dockerMachineFactory;
    private final List<String>                                  devMachinePortsToExpose;
    private final List<String>                                  commonMachinePortsToExpose;
    private final List<String>                                  devMachineSystemVolumes;
    private final List<String>                                  commonMachineSystemVolumes;
    private final Map<String, String>                           devMachineEnvVariables;
    private final Map<String, String>                           commonMachineEnvVariables;
    private final String[]                                      allMachinesExtraHosts;
    private final String                                        projectFolderPath;
    private final boolean                                       snapshotUseRegistry;
    private final double                                        memorySwapMultiplier;

    @Inject
    public ComposeMachineProviderImpl(DockerConnector docker,
                                      DockerConnectorConfiguration dockerConnectorConfiguration,
                                      UserSpecificDockerRegistryCredentialsProvider dockerCredentials,
                                      DockerMachineFactory dockerMachineFactory,
                                      DockerInstanceStopDetector dockerInstanceStopDetector,
                                      DockerContainerNameGenerator containerNameGenerator,
                                      @Named("machine.docker.dev_machine.machine_servers") Set<ServerConf> devMachineServers,
                                      @Named("machine.docker.machine_servers") Set<ServerConf> allMachinesServers,
                                      @Named("machine.docker.dev_machine.machine_volumes") Set<String> devMachineSystemVolumes,
                                      @Named("machine.docker.machine_volumes") Set<String> allMachinesSystemVolumes,
                                      @Nullable @Named("machine.docker.machine_extra_hosts") String allMachinesExtraHosts,
                                      WorkspaceFolderPathProvider workspaceFolderPathProvider,
                                      @Named("che.machine.projects.internal.storage") String projectFolderPath,
                                      @Named("machine.docker.pull_image") boolean doForcePullOnBuild,
                                      @Named("machine.docker.privilege_mode") boolean privilegeMode,
                                      @Named("machine.docker.dev_machine.machine_env") Set<String> devMachineEnvVariables,
                                      @Named("machine.docker.machine_env") Set<String> allMachinesEnvVariables,
                                      @Named("machine.docker.snapshot_use_registry") boolean snapshotUseRegistry,
                                      @Named("machine.docker.memory_swap_multiplier") double memorySwapMultiplier)
            throws IOException {
        this.docker = docker;
        this.dockerCredentials = dockerCredentials;
        this.dockerMachineFactory = dockerMachineFactory;
        this.dockerInstanceStopDetector = dockerInstanceStopDetector;
        this.containerNameGenerator = containerNameGenerator;
        this.workspaceFolderPathProvider = workspaceFolderPathProvider;
        this.doForcePullOnBuild = doForcePullOnBuild;
        this.privilegeMode = privilegeMode;
        this.projectFolderPath = projectFolderPath;
        this.snapshotUseRegistry = snapshotUseRegistry;
        // usecases:
        //  -1  enable unlimited swap
        //  0   disable swap
        //  0.5 enable swap with size equal to half of current memory size
        //  1   enable swap with size equal to current memory size
        //
        //  according to docker docs field  memorySwap should be equal to memory+swap
        //  we calculate this field as memorySwap=memory * (1+ multiplier) so we just add +1 to multiplier
        this.memorySwapMultiplier = memorySwapMultiplier == -1 ? -1 : memorySwapMultiplier + 1;

        allMachinesSystemVolumes = removeEmptyAndNullValues(allMachinesSystemVolumes);
        devMachineSystemVolumes = removeEmptyAndNullValues(devMachineSystemVolumes);
        if (SystemInfo.isWindows()) {
            allMachinesSystemVolumes = escapePaths(allMachinesSystemVolumes);
            devMachineSystemVolumes = escapePaths(devMachineSystemVolumes);
        }
        this.commonMachineSystemVolumes = new ArrayList<>(allMachinesSystemVolumes);
        List<String> devMachineVolumes = new ArrayList<>(allMachinesSystemVolumes.size()
                                                         + devMachineSystemVolumes.size());
        devMachineVolumes.addAll(allMachinesSystemVolumes);
        devMachineVolumes.addAll(devMachineSystemVolumes);
        this.devMachineSystemVolumes = devMachineVolumes;

        this.devMachinePortsToExpose = new ArrayList<>(allMachinesServers.size() + devMachineServers.size());
        this.commonMachinePortsToExpose = new ArrayList<>(allMachinesServers.size());
        for (ServerConf serverConf : devMachineServers) {
            devMachinePortsToExpose.add(serverConf.getPort());
        }
        for (ServerConf serverConf : allMachinesServers) {
            commonMachinePortsToExpose.add(serverConf.getPort());
            devMachinePortsToExpose.add(serverConf.getPort());
        }

        allMachinesEnvVariables = removeEmptyAndNullValues(allMachinesEnvVariables);
        devMachineEnvVariables = removeEmptyAndNullValues(devMachineEnvVariables);
        this.commonMachineEnvVariables = new HashMap<>();
        this.devMachineEnvVariables = new HashMap<>();
        allMachinesEnvVariables.forEach(envVar -> {
            String[] split = envVar.split("=", 2);
            this.commonMachineEnvVariables.put(split[0], split[1]);
            this.devMachineEnvVariables.put(split[0], split[1]);
        });
        devMachineEnvVariables.forEach(envVar -> {
            String[] split = envVar.split("=", 2);
            this.devMachineEnvVariables.put(split[0], split[1]);
        });

        // always add Che server to hosts list
        String cheHost = dockerConnectorConfiguration.getDockerHostIp();
        String cheHostAlias = DockerInstanceRuntimeInfo.CHE_HOST.concat(":").concat(cheHost);
        if (isNullOrEmpty(allMachinesExtraHosts)) {
            this.allMachinesExtraHosts = new String[] {cheHostAlias};
        } else {
            this.allMachinesExtraHosts = ObjectArrays.concat(allMachinesExtraHosts.split(","), cheHostAlias);
        }

        // TODO single point of failure in case of highly loaded system
        executor = Executors.newCachedThreadPool(new ThreadFactoryBuilder().setNameFormat("MachineLogsStreamer-%d")
                                                                           .setDaemon(true)
                                                                           .build());
    }

    @Override
    public Instance startService(String namespace,
                                 String workspaceId,
                                 String envName,
                                 String machineId,
                                 String machineName,
                                 boolean isDev,
                                 String networkName,
                                 ComposeServiceImpl service,
                                 LineConsumer machineLogger)
            throws ServerException {

        // copy to not affect/be affected by changes in origin
        service = new ComposeServiceImpl(service);

        ProgressLineFormatterImpl progressLineFormatter = new ProgressLineFormatterImpl();
        ProgressMonitor progressMonitor = currentProgressStatus -> {
            try {
                machineLogger.writeLine(progressLineFormatter.format(currentProgressStatus));
            } catch (IOException e) {
                LOG.error(e.getLocalizedMessage(), e);
            }
        };

        String container = null;
        try {
            String image = prepareImage(namespace,
                                        workspaceId,
                                        machineId,
                                        machineName,
                                        service,
                                        progressMonitor);

            container = createContainer(namespace,
                                        workspaceId,
                                        machineId,
                                        machineName,
                                        isDev,
                                        image,
                                        networkName,
                                        service);

            docker.startContainer(StartContainerParams.create(container));

            readContainerLogsInSeparateThread(container,
                                              workspaceId,
                                              machineId,
                                              machineLogger);

            DockerNode node = dockerMachineFactory.createNode(workspaceId, container);
            if (isDev) {
                node.bindWorkspace();
                LOG.info("Machine with id '{}' backed by container '{}' has been deployed on node '{}'",
                         machineId, container, node.getHost());
            }

            dockerInstanceStopDetector.startDetection(container,
                                                      machineId,
                                                      workspaceId);

            MachineImpl machine = new MachineImpl(MachineConfigImpl.builder()
                                                                   .setDev(isDev)
                                                                   .setName(machineName)
                                                                   .setType("docker")
                                                                   // casting considered as safe because more than int of megabytes is a lot!
                                                                   .setLimits(new MachineLimitsImpl((int)Size
                                                                           .parseSizeToMegabytes(
                                                                                   service.getMemLimit() + "b")))
                                                                   .setSource(new MachineSourceImpl(service.getBuild() != null ?
                                                                                                    "context" :
                                                                                                    "image")
                                                                                      .setLocation(service.getBuild() != null ?
                                                                                                   service.getBuild().getContext() :
                                                                                                   service.getImage()))
                                                                   .build(),
                                                  machineId,
                                                  workspaceId,
                                                  envName,
                                                  namespace,
                                                  MachineStatus.RUNNING,
                                                  null);

            return dockerMachineFactory.createInstance(machine,
                                                       container,
                                                       image,
                                                       node,
                                                       machineLogger);
        } catch (SourceNotFoundException e) {
            throw e;
        } catch (RuntimeException | ServerException | NotFoundException | IOException e) {
            cleanUpContainer(container);
            throw new ServerException(e.getLocalizedMessage());
        }
    }

    @Override
    public void createNetwork(String networkName) throws ServerException {
        try {
            docker.createNetwork(CreateNetworkParams.create(new NewNetwork().withName(networkName)
                                                                            .withCheckDuplicate(true)));
        } catch (IOException e) {
            throw new ServerException(e.getLocalizedMessage(), e);
        }
    }

    @Override
    public void destroyNetwork(String networkName) throws ServerException {
        try {
            docker.removeNetwork(RemoveNetworkParams.create(networkName));
        } catch (NetworkNotFoundException ignore) {
        } catch (IOException e) {
            throw new ServerException(e.getLocalizedMessage(), e);
        }
    }

    private String prepareImage(String namespace,
                                String workspaceId,
                                String machineId,
                                String machineName,
                                ComposeServiceImpl service,
                                ProgressMonitor progressMonitor)
            throws ServerException,
                   NotFoundException {

        String containerName = generateContainerName(namespace, workspaceId, machineId, machineName);
        String imageName = "eclipse-che/" + containerName;
        // workaround: dockerfile content can be in service.build.dockerfile
        if ((service.getBuild() == null ||
             (service.getBuild().getContext() == null && service.getBuild().getDockerfile() == null)) &&
            service.getImage() == null) {

            throw new ServerException(format("Compose service '%s' doesn't have neither build not image fields",
                                             machineName));
        }

        if (service.getBuild() != null && (service.getBuild().getContext() != null ||
                                           service.getBuild().getDockerfile() != null)) {
            buildImage(service, imageName, doForcePullOnBuild, progressMonitor);
        } else {
            pullImage(service, imageName, progressMonitor);
        }

        return imageName;
    }

    protected void buildImage(ComposeServiceImpl service,
                              String machineImageName,
                              boolean doForcePullOnBuild,
                              ProgressMonitor progressMonitor)
            throws MachineException {

        File workDir = null;
        try {
            BuildImageParams buildImageParams;
            // workaround: dockerfile content can be in service.build.dockerfile
            if (service.getBuild() != null &&
                service.getBuild().getContext() == null &&
                service.getBuild().getDockerfile() != null) {

                workDir = Files.createTempDirectory(null).toFile();
                final File dockerfileFile = new File(workDir, "Dockerfile");
                try (FileWriter output = new FileWriter(dockerfileFile)) {
                    output.append(service.getBuild().getDockerfile());
                }

                buildImageParams = BuildImageParams.create(dockerfileFile);
            } else {
                buildImageParams = BuildImageParams.create(service.getBuild().getContext())
                                                   .withDockerfile(service.getBuild().getDockerfile());
            }
            buildImageParams.withForceRemoveIntermediateContainers(true)
                            .withRepository(machineImageName)
                            .withAuthConfigs(dockerCredentials.getCredentials())
                            .withDoForcePull(doForcePullOnBuild)
                            .withMemoryLimit(service.getMemLimit())
                            .withMemorySwapLimit(-1);

            docker.buildImage(buildImageParams, progressMonitor);
        } catch (IOException e) {
            throw new MachineException(e.getLocalizedMessage(), e);
        } finally {
            if (workDir != null) {
                FileCleaner.addFile(workDir);
            }
        }
    }

    protected void pullImage(ComposeServiceImpl service,
                             String machineImageName,
                             ProgressMonitor progressMonitor) throws NotFoundException,
                                                                     MachineException,
                                                                     SourceNotFoundException {
        DockerMachineSource dockerMachineSource = new DockerMachineSource(
                new MachineSourceImpl("image").setLocation(service.getImage()));
        if (dockerMachineSource.getRepository() == null) {
            throw new MachineException(
                    format("Machine creation failed. Machine source is invalid. No repository is defined. Found '%s'.",
                           dockerMachineSource));
        }

        try {
            boolean isSnapshot = SNAPSHOT_LOCATION_PATTERN.matcher(dockerMachineSource.getLocation()).matches();
            if (!isSnapshot || snapshotUseRegistry) {
                PullParams pullParams = PullParams.create(dockerMachineSource.getRepository())
                                                  .withTag(MoreObjects.firstNonNull(dockerMachineSource.getTag(),
                                                                                    LATEST_TAG))
                                                  .withRegistry(dockerMachineSource.getRegistry())
                                                  .withAuthConfigs(dockerCredentials.getCredentials());
                docker.pull(pullParams, progressMonitor);
            }

            String fullNameOfPulledImage = dockerMachineSource.getLocation(false);
            try {
                // tag image with generated name to allow sysadmin recognize it
                docker.tag(TagParams.create(fullNameOfPulledImage, machineImageName));
            } catch (ImageNotFoundException nfEx) {
                throw new SourceNotFoundException(nfEx.getLocalizedMessage(), nfEx);
            }

            // remove unneeded tag if restoring snapshot from registry
            if (isSnapshot && snapshotUseRegistry) {
                docker.removeImage(RemoveImageParams.create(fullNameOfPulledImage).withForce(false));
            }
        } catch (IOException e) {
            LOG.error(e.getLocalizedMessage(), e);
            throw new MachineException("Can't create machine from image. Cause: " + e.getLocalizedMessage());
        }
    }

    private String createContainer(String namespace,
                                   String workspaceId,
                                   String machineId,
                                   String machineName,
                                   boolean isDev,
                                   String image,
                                   String networkName,
                                   ComposeServiceImpl service) throws IOException {

        long machineMemorySwap = memorySwapMultiplier == -1 ?
                                 -1 :
                                 (long)(service.getMemLimit() * memorySwapMultiplier);

        String containerName = generateContainerName(namespace, workspaceId, machineId, machineName);

        addSystemWideContainerSettings(workspaceId,
                                       isDev,
                                       service);

        EndpointConfig endpointConfig = new EndpointConfig().withAliases(machineName);
        NetworkingConfig networkingConfig = new NetworkingConfig().withEndpointsConfig(singletonMap(networkName,
                                                                                                    endpointConfig));

        HostConfig hostConfig = new HostConfig();
        hostConfig.withBinds(toArrayIfNotNull(service.getVolumes()))
                  .withExtraHosts(allMachinesExtraHosts)
                  .withPublishAllPorts(true)
                  .withMemorySwap(machineMemorySwap)
                  .withMemory(service.getMemLimit())
                  .withPrivileged(privilegeMode)
                  .withNetworkMode(networkName)
                  .withLinks(toArrayIfNotNull(service.getLinks()))
                  .withPortBindings(service.getPorts()
                                           .stream()
                                           .collect(Collectors.toMap(Function.identity(),
                                                                     value -> new PortBinding[0])))
                  .withVolumesFrom(toArrayIfNotNull(service.getVolumesFrom()));

        ContainerConfig config = new ContainerConfig();
        config.withImage(image)
              .withExposedPorts(service.getExpose().stream().collect(Collectors.toMap(Function.identity(),
                                                                                      value -> Collections.emptyMap())))
              .withHostConfig(hostConfig)
              .withCmd(toArrayIfNotNull(service.getCommand()))
              .withEntrypoint(toArrayIfNotNull(service.getEntrypoint()))
              .withLabels(service.getLabels())
              .withNetworkingConfig(networkingConfig)
              .withEnv(service.getEnvironment()
                              .entrySet()
                              .stream()
                              .map(entry -> entry.getKey() + "=" + entry.getValue())
                              .toArray(String[]::new));

        return docker.createContainer(CreateContainerParams.create(config)
                                                           .withContainerName(containerName))
                     .getId();
    }

    private void addSystemWideContainerSettings(String workspaceId,
                                                boolean isDev,
                                                ComposeServiceImpl composeService) throws IOException {
        List<String> portsToExpose;
        List<String> volumes;
        Map<String, String> env;
        if (isDev) {
            portsToExpose = devMachinePortsToExpose;

            volumes = new ArrayList<>(devMachineSystemVolumes.size() + 1);
            volumes.addAll(devMachineSystemVolumes);
            String projectFolderVolume = format("%s:%s:Z",
                                                workspaceFolderPathProvider.getPath(workspaceId),
                                                projectFolderPath);
            volumes.add(SystemInfo.isWindows() ? escapePath(projectFolderVolume)
                                               : projectFolderVolume);

            env = new HashMap<>(devMachineEnvVariables);
            env.put(DockerInstanceRuntimeInfo.CHE_WORKSPACE_ID, workspaceId);
            env.put(DockerInstanceRuntimeInfo.USER_TOKEN, getUserToken(workspaceId));
        } else {
            portsToExpose = commonMachinePortsToExpose;
            env = commonMachineEnvVariables;
            volumes = commonMachineSystemVolumes;
        }
        composeService.getExpose().addAll(portsToExpose);
        composeService.getEnvironment().putAll(env);
        composeService.getVolumes().addAll(volumes);
    }

    private void readContainerLogsInSeparateThread(String container,
                                                   String workspaceId,
                                                   String machineId,
                                                   LineConsumer outputConsumer) {
        executor.execute(() -> {
            long lastProcessedLogDate = 0;
            boolean isContainerRunning = true;
            while (isContainerRunning) {
                try {
                    docker.getContainerLogs(GetContainerLogsParams.create(container)
                                                                  .withFollow(true)
                                                                  .withSince(lastProcessedLogDate),
                                            new LogMessagePrinter(outputConsumer));
                    isContainerRunning = false;
                } catch (SocketTimeoutException ste) {
                    lastProcessedLogDate = System.currentTimeMillis() / 1000L;
                    // reconnect to container
                } catch (ContainerNotFoundException e) {
                    isContainerRunning = false;
                } catch (IOException e) {
                    LOG.error("Failed to get logs from machine {} of workspace {} backed by container {}",
                              workspaceId,
                              machineId,
                              container);
                }
            }
        });
    }

    private String generateContainerName(String namespace,
                                         String workspaceId,
                                         String machineId,
                                         String machineName) {
        return containerNameGenerator.generateContainerName(workspaceId,
                                                            machineId,
                                                            namespace,
                                                            machineName);
    }

    private void cleanUpContainer(String containerId) {
        try {
            if (containerId != null) {
                docker.removeContainer(RemoveContainerParams.create(containerId)
                                                            .withRemoveVolumes(true)
                                                            .withForce(true));
            }
        } catch (Exception ex) {
            LOG.error("Failed to remove docker container {}", containerId, ex);
        }
    }

    // workspaceId parameter is required, because in case of separate storage for tokens
    // you need to know exactly which workspace and which user to apply the token.
    protected String getUserToken(String wsId) {
        return EnvironmentContext.getCurrent().getSubject().getToken();
    }

    /**
     * Returns set that contains all non empty and non nullable values from specified set
     */
    protected Set<String> removeEmptyAndNullValues(Set<String> paths) {
        return paths.stream()
                    .filter(path -> !Strings.isNullOrEmpty(path))
                    .collect(Collectors.toSet());
    }

    /**
     * Escape paths for Windows system with boot@docker according to rules given here :
     * https://github.com/boot2docker/boot2docker/blob/master/README.md#virtualbox-guest-additions
     *
     * @param paths
     *         set of paths to escape
     * @return set of escaped path
     */
    private Set<String> escapePaths(Set<String> paths) {
        return paths.stream().map(this::escapePath).collect(Collectors.toSet());
    }

    /**
     * Escape path for Windows system with boot@docker according to rules given here :
     * https://github.com/boot2docker/boot2docker/blob/master/README.md#virtualbox-guest-additions
     *
     * @param path
     *         path to escape
     * @return escaped path
     */
    @VisibleForTesting
    String escapePath(String path) {
        String esc;
        if (path.indexOf(":") == 1) {
            //check and replace only occurrence of ":" after disk label on Windows host (e.g. C:/)
            // but keep other occurrences it can be marker for docker mount volumes
            // (e.g. /path/dir/from/host:/name/of/dir/in/container                                               )
            esc = path.replaceFirst(":", "").replace('\\', '/');
            esc = Character.toLowerCase(esc.charAt(0)) + esc.substring(1); //letter of disk mark must be lower case
        } else {
            esc = path.replace('\\', '/');
        }
        if (!esc.startsWith("/")) {
            esc = "/" + esc;
        }
        return esc;
    }

    /** Converts list to array if it is not null, otherwise returns null */
    private String[] toArrayIfNotNull(List<String> list) {
        if (list == null) {
            return null;
        }
        return list.toArray(new String[list.size()]);
    }
}
