from .cherry_picker import cherry_pick_cli

if __name__ == "__main__":
    cherry_pick_cli()
